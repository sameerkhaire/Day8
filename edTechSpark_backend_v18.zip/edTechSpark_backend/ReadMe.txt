Steps to run the project
	For Backend
	- Make api project as startup 
	- Change the connnection string in appsetting.json
	- Open Tools => Package Manager => Package manager console 
	- > Update-Database
	- Run the api project
	- Run edTech.DAL/SqlScritps/SeedData.sql in mssql to add dummy data
	
	-Open swagger
	-Add user (user can be added from screen using signup) 
	-Add admin from api
	(Note: Make sure password should contain caps/character/special character/digits)

	For FrontEnd
	- Open the folder in vscode
	- npm install
	- ng serve
