import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullsize-layout',
  templateUrl: './fullsize-layout.component.html',
  styles: [
  ]
})
export class FullsizeLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
