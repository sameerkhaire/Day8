import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorize',
  templateUrl: './unauthorize.component.html',
  styles: [
  ]
})
export class UnauthorizeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
