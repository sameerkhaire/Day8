import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  templateUrl: './notfound.component.html',
  styles: [
  ]
})
export class NotfoundComponent {



}
