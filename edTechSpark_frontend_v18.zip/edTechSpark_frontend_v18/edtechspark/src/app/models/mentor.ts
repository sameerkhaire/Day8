export class Mentor {
    id: number | any;
    name: string | undefined;
    email: string | undefined;
    title: string | undefined;
    biography: string | undefined;
    skills: string | undefined;
    imageUrl: string | undefined;
}