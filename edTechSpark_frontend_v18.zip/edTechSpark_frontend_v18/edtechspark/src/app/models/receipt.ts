export class Receipt {
    paymentId: string | undefined;
    currency: string | undefined;
    email: string | undefined;
    status: string | undefined;
    grandTotal: number | undefined;
}