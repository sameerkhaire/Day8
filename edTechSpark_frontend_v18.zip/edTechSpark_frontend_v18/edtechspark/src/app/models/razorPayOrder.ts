export class RazorPayOrder {
    constructor(public grandTotal: number, public currency: string, public receipt: string) {
      
     }
  }