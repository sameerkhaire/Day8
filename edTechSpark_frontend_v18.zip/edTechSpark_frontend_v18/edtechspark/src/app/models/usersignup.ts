export class UserSignup {
    id: number | undefined;
    email: string | undefined;
    name: string | undefined;
    password: string | undefined;
    confirmPassword: string | undefined;
    phoneNumber: string | undefined;
}