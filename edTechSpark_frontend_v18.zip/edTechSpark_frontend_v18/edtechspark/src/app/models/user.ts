export class User {
    id: number | any;
    name: string | undefined;
    email: string | undefined;
    phoneNumber: string | undefined;
    roles: string[] | any;
    token: string | undefined;
}