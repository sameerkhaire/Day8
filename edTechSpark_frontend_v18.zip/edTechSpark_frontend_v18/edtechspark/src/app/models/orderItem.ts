export class OrderItem {
    id: number | any;
    name: string | any;
    description: string | any;
    itemId: number | any;
    unitPrice: number | any;
    quantity: number | any;
    total: number | any;
    imageUrl: string | any;
}