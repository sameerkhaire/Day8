export class Category {
    id: string | any;
    name: string | undefined;
    description: string | undefined;
}