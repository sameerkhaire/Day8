import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashbaord',
  templateUrl: './dashbaord.component.html',
  styles: [
  ]
})
export class DashbaordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
