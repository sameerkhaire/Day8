import { Component } from '@angular/core';

@Component({
  selector: 'app-user-layout',
  templateUrl: './user-layout.component.html',
  styles: [
  ]
})
export class UserLayoutComponent{

  constructor() { }


}
