export const AUTH_ID = 'aid';
export const RECEIPT_ID = 'rid';
export const CART_ID='cid';