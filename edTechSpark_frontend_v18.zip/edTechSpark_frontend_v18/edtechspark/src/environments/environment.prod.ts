export const environment = {
  production: true,
  apiAddress:'http://localhost:62049/api',
  encKey:'SecretKey',
  imageServer:'http://localhost:62049',
  razorPay:{
    key:"rzp_test_iS4ZXWqjE5NVAq"
  }
};
