
export const environment = {
  production: false,
  apiAddress:'http://localhost:62049/api',//'https://edtechsparkapi.azurewebsites.net/api',
  encKey:'SecretKey',
  imageServer:'http://localhost:62049',
  razorPay:{
    key:"rzp_test_iS4ZXWqjE5NVAq"
  }
};

